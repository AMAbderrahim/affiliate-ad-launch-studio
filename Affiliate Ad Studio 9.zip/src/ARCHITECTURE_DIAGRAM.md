# 🏗️ Architecture Diagram

Visual guide to the Affiliate Ad Launch Studio architecture and deployment flow.

---

## 🎯 Complete System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER'S BROWSER                          │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │              Your Deployed App                           │  │
│  │         https://your-app.vercel.app                      │  │
│  │                                                          │  │
│  │  ┌────────────┐  ┌────────────┐  ┌──────────────┐      │  │
│  │  │  Login     │  │  Main      │  │   Weekly     │      │  │
│  │  │  Page      │  │  Data Hub  │  │   Reports    │      │  │
│  │  └────────────┘  └────────────┘  └──────────────┘      │  │
│  │                                                          │  │
│  │  ┌────────────────────────────────────────────────────┐ │  │
│  │  │          11 AI Agent Pages                         │ │  │
│  │  │  • Marketing Strategist  • Media Buyer             │ │  │
│  │  │  • Creative Strategist   • Data Ops                │ │  │
│  │  │  • Video Director        • Compliance              │ │  │
│  │  │  • Designer             • Competitor Analysis      │ │  │
│  │  │  • Prompt Generator     • Campaign Scheduler       │ │  │
│  │  │  • Copywriter                                      │ │  │
│  │  └────────────────────────────────────────────────────┘ │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ React + TypeScript
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        ▼                     ▼                     ▼
┌──────────────┐    ┌──────────────────┐    ┌──────────────┐
│   Google     │    │   Cloudflare     │    │    Vercel    │
│   OAuth      │    │   Worker         │    │    CDN       │
│              │    │                  │    │              │
│ Handles Auth │    │ Proxies to API   │    │ Hosts App    │
└──────────────┘    └──────────────────┘    └──────────────┘
                              │
                              │ Secure API Call
                              │
                              ▼
                    ┌──────────────────┐
                    │  Google Gemini   │
                    │      API         │
                    │                  │
                    │ AI Responses     │
                    └──────────────────┘
```

---

## 📦 Build & Deployment Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    LOCAL DEVELOPMENT                        │
└─────────────────────────────────────────────────────────────┘
                              │
                              │ Code Changes
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  git add . && git commit -m "message" && git push           │
└─────────────────────────────────────────────────────────────┘
                              │
                              │ Push to GitHub
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                         GITHUB                              │
│  ┌────────────────────────────────────────────────────┐    │
│  │  affiliate-ad-launch-studio/                       │    │
│  │  ├── App.tsx                                       │    │
│  │  ├── components/ (62 files)                        │    │
│  │  ├── public/ (7 files)                             │    │
│  │  ├── vercel.json                                   │    │
│  │  └── ... (111 total files)                         │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                              │
                              │ Webhook Trigger
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    VERCEL BUILD PROCESS                     │
│                                                             │
│  Step 1: Clone Repository                                  │
│  ┌───────────────────────────────────────────────────┐    │
│  │ git clone https://github.com/user/repo.git        │    │
│  └───────────────────────────────────────────────────┘    │
│                              │                             │
│  Step 2: Install Dependencies                              │
│  ┌───────────────────────────────────────────────────┐    │
│  │ npm install                                        │    │
│  └───────────────────────────────────────────────────┘    │
│                              │                             │
│  Step 3: Load Environment Variables                        │
│  ┌───────────────────────────────────────────────────┐    │
│  │ VITE_AGENT_WORKER=https://worker.dev              │    │
│  │ VITE_GOOGLE_CLIENT_ID=123-abc.apps.google.com     │    │
│  └───────────────────────────────────────────────────┘    │
│                              │                             │
│  Step 4: Run Build                                         │
│  ┌───────────────────────────────────────────────────┐    │
│  │ npm run build                                      │    │
│  │   → vite build                                     │    │
│  │   → TypeScript compile                             │    │
│  │   → Code splitting                                 │    │
│  │   → Minification                                   │    │
│  │   → Output to dist/                                │    │
│  └───────────────────────────────────────────────────┘    │
│                              │                             │
│  Step 5: Deploy to CDN                                     │
│  ┌───────────────────────────────────────────────────┐    │
│  │ dist/ → Vercel Global CDN                          │    │
│  └───────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                              │
                              │ Deployment Complete
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    LIVE APPLICATION                         │
│              https://your-app.vercel.app                    │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔄 User Interaction Flow

```
┌──────────┐
│  User    │
└────┬─────┘
     │
     │ 1. Visits App
     ▼
┌─────────────────────┐
│  Login Page         │
│  (LoginPage.tsx)    │
└─────────┬───────────┘
          │
          │ 2. Clicks "Sign in with Google"
          ▼
┌─────────────────────┐
│  Google OAuth       │
│  Authentication     │
└─────────┬───────────┘
          │
          │ 3. Returns with token
          ▼
┌─────────────────────┐
│  AuthContext        │
│  (Sets isAuth=true) │
└─────────┬───────────┘
          │
          │ 4. Redirects to Main App
          ▼
┌─────────────────────────────────────────┐
│  Main App (App.tsx)                     │
│  ┌────────────┐  ┌──────────────────┐  │
│  │ Navigation │  │  Main Content    │  │
│  │ Sidebar    │  │  Area            │  │
│  │            │  │                  │  │
│  │ • Home     │  │  Selected Page   │  │
│  │ • Agents   │  │  Renders Here    │  │
│  │ • Reports  │  │                  │  │
│  └────────────┘  └──────────────────┘  │
└─────────────────────────────────────────┘
          │
          │ 5. User selects an Agent
          ▼
┌─────────────────────────────────────────┐
│  Agent Page (e.g., MarketingStrategist) │
│  ┌────────────────────────────────────┐ │
│  │  AgentLayout                       │ │
│  │  ┌──────────────────────────────┐  │ │
│  │  │  AgentChatPanel              │  │ │
│  │  │  ┌────────────────────────┐  │  │ │
│  │  │  │ User: "Create campaign"│  │  │ │
│  │  │  └────────────────────────┘  │  │ │
│  │  └──────────────────────────────┘  │ │
│  └────────────────────────────────────┘ │
└─────────────────────────────────────────┘
          │
          │ 6. Sends message
          ▼
┌─────────────────────────────────────────┐
│  workerService.tsx                      │
│  sendMessage()                          │
└─────────┬───────────────────────────────┘
          │
          │ 7. POST to Worker
          ▼
┌─────────────────────────────────────────┐
│  Cloudflare Worker                      │
│  (your-worker.workers.dev)              │
│                                         │
│  • Validates request                    │
│  • Checks CORS                          │
│  • Adds context                         │
└─────────┬───────────────────────────────┘
          │
          │ 8. Forwards to Gemini
          ▼
┌─────────────────────────────────────────┐
│  Google Gemini API                      │
│  generativelanguage.googleapis.com      │
│                                         │
│  • Processes prompt                     │
│  • Generates response                   │
└─────────┬───────────────────────────────┘
          │
          │ 9. Returns AI response
          ▼
┌─────────────────────────────────────────┐
│  Cloudflare Worker                      │
│  • Formats response                     │
│  • Adds metadata                        │
└─────────┬───────────────────────────────┘
          │
          │ 10. Returns to App
          ▼
┌─────────────────────────────────────────┐
│  AgentChatPanel                         │
│  ┌────────────────────────────────────┐ │
│  │ User: "Create campaign"            │ │
│  │ AI: "Here's your campaign plan..." │ │
│  └────────────────────────────────────┘ │
└─────────────────────────────────────────┘
          │
          │ 11. Displays to user
          ▼
┌──────────┐
│  User    │
│  (Sees   │
│  response)│
└──────────┘
```

---

## 📁 File Structure in Production

```
dist/ (Deployed to Vercel)
│
├── index.html                    # Entry point
│   <html>
│     <div id="root"></div>
│     <script src="/assets/index-abc123.js"></script>
│   </html>
│
├── assets/
│   ├── index-abc123.js          # Main app bundle
│   │   • All React components
│   │   • All TypeScript code
│   │   • All business logic
│   │   • Minified & optimized
│   │
│   ├── index-def456.css         # Compiled styles
│   │   • All Tailwind CSS
│   │   • Component styles
│   │   • Global styles
│   │   • Minified
│   │
│   ├── react-vendor-ghi789.js   # React libraries
│   │   • React
│   │   • React DOM
│   │   • React Router
│   │   • Cached separately
│   │
│   └── ui-vendor-jkl012.js      # UI libraries
│       • Lucide icons
│       • Other UI libs
│       • Cached separately
│
├── vite.svg                     # Logo
├── robots.txt                   # SEO
└── manifest.json                # PWA config

Total size: ~500KB gzipped
Load time: ~1-2 seconds
```

---

## 🔐 Security Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    CLIENT (Browser)                     │
│  ┌────────────────────────────────────────────────┐    │
│  │  Environment Variables (Build-time embedded)   │    │
│  │  • VITE_AGENT_WORKER (public, OK)              │    │
│  │  • VITE_GOOGLE_CLIENT_ID (public, OK)          │    │
│  └────────────────────────────────────────────────┘    │
│                                                         │
│  ⚠️ No API keys in browser!                            │
└─────────────────────────────────────────────────────────┘
                              │
                              │ HTTPS only
                              ▼
┌─────────────────────────────────────────────────────────┐
│              CLOUDFLARE WORKER (Edge)                   │
│  ┌────────────────────────────────────────────────┐    │
│  │  Secrets (Server-side, encrypted)              │    │
│  │  • GEMINI_API_KEY (private, secure)            │    │
│  └────────────────────────────────────────────────┘    │
│                                                         │
│  ✅ API key never exposed to client                    │
│  ✅ CORS validation                                     │
│  ✅ Rate limiting                                       │
└─────────────────────────────────────────────────────────┘
                              │
                              │ Authorized requests only
                              ▼
┌─────────────────────────────────────────────────────────┐
│                  GOOGLE GEMINI API                      │
│  ✅ Receives requests from Worker only                  │
│  ✅ Not accessible from browser                         │
└─────────────────────────────────────────────────────────┘
```

---

## 🌍 Global Deployment Architecture

```
                    ┌──────────────┐
                    │   GitHub     │
                    │  Repository  │
                    └──────┬───────┘
                           │
                           │ Push triggers deploy
                           ▼
            ┌──────────────────────────────┐
            │     Vercel Build System      │
            │  (Automated CI/CD Pipeline)  │
            └──────────────┬───────────────┘
                           │
                           │ Deploys to Global CDN
                           ▼
    ┌──────────────────────────────────────────────────┐
    │          Vercel Global CDN (70+ Locations)       │
    │                                                  │
    │  🌍 North America   🌍 Europe   🌍 Asia         │
    │  🌍 South America   🌍 Africa   🌍 Oceania      │
    │                                                  │
    │  Each location serves your app instantly!        │
    └──────────────────────────────────────────────────┘
                           │
                           │ Users connect to nearest
                           ▼
                    ┌──────────────┐
                    │     User     │
                    │   (< 100ms)  │
                    └──────────────┘


    Meanwhile, Cloudflare Worker runs at edge:
    
    ┌──────────────────────────────────────────────────┐
    │     Cloudflare Edge Network (300+ Locations)     │
    │                                                  │
    │  Processes AI requests closest to user           │
    │  Ultra-low latency (< 50ms to worker)           │
    └──────────────────────────────────────────────────┘
```

---

## 🔄 Continuous Deployment Flow

```
Developer → Code Change
     │
     │ git commit && git push
     ▼
┌─────────────────────┐
│      GitHub         │
│  (Source of Truth)  │
└──────────┬──────────┘
           │
           │ Webhook notification
           ▼
┌─────────────────────────────────────┐
│     Vercel Deployment System        │
│                                     │
│  1. Pull latest code                │
│  2. Install dependencies            │
│  3. Run type check                  │
│  4. Run build                       │
│  5. Run tests (if configured)       │
│  6. Deploy to preview (if PR)       │
│  7. Deploy to production (if main)  │
└──────────┬──────────────────────────┘
           │
           │ ✅ Success
           ▼
┌─────────────────────┐
│   Live Update!      │
│  (Automatic)        │
└─────────────────────┘
           │
           │ Notification
           ▼
┌─────────────────────┐
│  Developer          │
│  • Email alert      │
│  • Slack message    │
│  • GitHub comment   │
└─────────────────────┘
```

---

## 📊 Data Flow Diagram

```
┌────────────────────────────────────────────────────────────┐
│                    DATA FLOW                                │
└────────────────────────────────────────────────────────────┘

User Input
    │
    │ "Create a marketing campaign"
    ▼
┌─────────────────────┐
│  AgentChatPanel     │
│  (React Component)  │
└──────────┬──────────┘
           │
           │ setState({ message: "..." })
           ▼
┌─────────────────────────┐
│  workerService.tsx      │
│  sendMessage(agent, msg)│
└──────────┬──────────────┘
           │
           │ fetch(WORKER_URL, { ... })
           ▼
┌─────────────────────────────────┐
│  Cloudflare Worker              │
│  POST /api/chat                 │
│  {                              │
│    agent: "marketing",          │
│    message: "Create campaign"   │
│  }                              │
└──────────┬──────────────────────┘
           │
           │ Gemini API call
           ▼
┌─────────────────────────────────┐
│  Google Gemini API              │
│  model: gemini-1.5-pro          │
│  prompt: [system] + [user msg]  │
└──────────┬──────────────────────┘
           │
           │ AI Response
           ▼
┌─────────────────────────────────┐
│  Cloudflare Worker              │
│  {                              │
│    response: "Here's your..."   │
│    tokens: 1234                 │
│  }                              │
└──────────┬──────────────────────┘
           │
           │ JSON response
           ▼
┌─────────────────────────────────┐
│  workerService.tsx              │
│  return await response.json()   │
└──────────┬──────────────────────┘
           │
           │ Update state
           ▼
┌─────────────────────────────────┐
│  AgentChatPanel                 │
│  setMessages([...old, new])     │
└──────────┬──────────────────────┘
           │
           │ React re-render
           ▼
┌─────────────────────────────────┐
│  User sees response in UI       │
└─────────────────────────────────┘
```

---

## 🎯 Technology Stack Visualization

```
┌─────────────────────────────────────────────────────────────┐
│                      FRONTEND STACK                         │
│  ┌────────────┐  ┌────────────┐  ┌─────────────────────┐  │
│  │   React    │  │ TypeScript │  │  Tailwind CSS 4.0   │  │
│  │   18.3.1   │  │    5.5.2   │  │  (Utility-first)    │  │
│  └────────────┘  └────────────┘  └─────────────────────┘  │
│                                                             │
│  ┌────────────┐  ┌────────────┐  ┌─────────────────────┐  │
│  │   Vite     │  │ React      │  │   Shadcn/ui         │  │
│  │   5.3.1    │  │ Router     │  │   (42 components)   │  │
│  │  (Build)   │  │  6.26.1    │  │                     │  │
│  └────────────┘  └────────────┘  └─────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                     BACKEND STACK                           │
│  ┌────────────────┐  ┌──────────────────────────────────┐  │
│  │  Cloudflare    │  │     Google Gemini API            │  │
│  │   Workers      │  │  • gemini-1.5-pro                │  │
│  │  (Edge)        │  │  • gemini-1.5-flash              │  │
│  │                │  │  • 70-95% cost savings           │  │
│  └────────────────┘  └──────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                  DEPLOYMENT & HOSTING                       │
│  ┌────────────┐  ┌────────────┐  ┌─────────────────────┐  │
│  │   Vercel   │  │   GitHub   │  │  Google OAuth       │  │
│  │   (CDN)    │  │  (Code)    │  │  (Authentication)   │  │
│  └────────────┘  └────────────┘  └─────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

---

## 📈 Performance Architecture

```
First Request (Cold Start)
┌──────────────────────────────────────────────┐
│ User → DNS → CDN → Static Files → Parse     │
│ ~50ms  ~20ms  ~100ms    ~200ms     ~300ms   │
│                                              │
│ Total First Load: ~670ms                     │
└──────────────────────────────────────────────┘

Subsequent Requests (Cached)
┌──────────────────────────────────────────────┐
│ User → Browser Cache → Instant Load          │
│                        ~50ms                 │
│                                              │
│ Total: ~50ms (98% faster!)                   │
└──────────────────────────────────────────────┘

Agent API Call
┌──────────────────────────────────────────────┐
│ User → Worker → Gemini → Response           │
│ ~20ms  ~50ms    ~500-2000ms  ~50ms          │
│                                              │
│ Total: ~620-2120ms (reasonable for AI)       │
└──────────────────────────────────────────────┘
```

---

**This architecture ensures:**

✅ Fast global load times (< 2s)  
✅ Secure API key management  
✅ Scalable to millions of users  
✅ Cost-effective operation  
✅ Easy updates and rollbacks  
✅ 99.9%+ uptime  

**Ready to deploy this architecture?**  
→ [START_DEPLOYMENT.md](START_DEPLOYMENT.md)
