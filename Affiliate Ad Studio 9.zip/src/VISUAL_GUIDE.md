# 📊 Visual Configuration Guide

## 🎯 The Simple Answer

```
┌────────────────────────────────────────────────────────────────┐
│                                                                │
│  Q: Where do I add my Worker URL and Google Client ID?       │
│                                                                │
│  A: In the .env file in your project root!                   │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

---

## 📁 File Location

```
your-affiliate-ad-studio/
│
├── 📄 .env                    ⬅️ EDIT THIS FILE!
│   ├── VITE_AGENT_WORKER=https://...
│   └── VITE_GOOGLE_CLIENT_ID=...
│
├── 📄 .env.example            (template - don't edit)
├── 📄 README.md
├── 📄 App.tsx
├── 📁 components/
├── 📁 context/
│   └── AuthContext.tsx        (reads your Google Client ID)
├── 📁 services/
│   └── workerService.tsx      (reads your Worker URL)
└── ...
```

---

## 🔄 Configuration Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                     STEP 1: CREATE .ENV FILE                    │
│                                                                 │
│  File: .env (in project root)                                  │
│  ┌───────────────────────────────────────────────────────┐     │
│  │ VITE_AGENT_WORKER=https://your-worker.workers.dev    │     │
│  │ VITE_GOOGLE_CLIENT_ID=your-id.apps.googleusercontent │     │
│  └───────────────────────────────────────────────────────┘     │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                  STEP 2: GET CLOUDFLARE WORKER URL              │
│                                                                 │
│  1. Deploy worker (see WORKER_SETUP.md)                        │
│  2. Copy URL: https://your-worker-name.workers.dev             │
│  3. Add to .env: VITE_AGENT_WORKER=https://...                 │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                 STEP 3: GET GOOGLE CLIENT ID                    │
│                                                                 │
│  1. Go to console.cloud.google.com/apis/credentials            │
│  2. Create OAuth 2.0 Client ID                                 │
│  3. Copy ID: 123456789012-abc...xyz.apps.googleusercontent.com │
│  4. Add to .env: VITE_GOOGLE_CLIENT_ID=...                     │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                   STEP 4: RESTART DEV SERVER                    │
│                                                                 │
│  Terminal:                                                      │
│  $ npm run dev                                                  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                       ✅ READY TO USE! ✅                       │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🏗️ Architecture Diagram

```
┌──────────────────────────────────────────────────────────────────┐
│                      YOUR APPLICATION                            │
│                                                                  │
│  ┌─────────────────────┐         ┌─────────────────────┐        │
│  │  Login Page         │         │  Agent Pages        │        │
│  │                     │         │                     │        │
│  │  Uses:              │         │  Uses:              │        │
│  │  • AuthContext ────────────────▶ WorkerService      │        │
│  │  • Google Sign-In   │         │  • Agent requests   │        │
│  └─────────────────────┘         └─────────────────────┘        │
│           │                                 │                    │
└───────────┼─────────────────────────────────┼────────────────────┘
            │                                 │
            │                                 │
            ▼                                 ▼
   ┌──────────────────┐            ┌──────────────────────┐
   │  GOOGLE OAUTH    │            │  CLOUDFLARE WORKER   │
   │                  │            │                      │
   │  Needs:          │            │  Needs:              │
   │  Client ID ◀─────┼─┐          │  Worker URL ◀────────┼─┐
   └──────────────────┘ │          └──────────────────────┘ │
                        │                                   │
                        │                                   │
                   ┌────┴───────────────────────────────────┴─────┐
                   │                                              │
                   │          .ENV FILE (PROJECT ROOT)            │
                   │                                              │
                   │  VITE_GOOGLE_CLIENT_ID=your-client-id      │
                   │  VITE_AGENT_WORKER=https://your-worker.dev │
                   │                                              │
                   └──────────────────────────────────────────────┘
```

---

## 📝 The .env File Contents

```bash
# ============================================================================
#                       AFFILIATE AD LAUNCH STUDIO
#                       CONFIGURATION FILE
# ============================================================================

# ----------------------------------------------------------------------------
# 1️⃣ CLOUDFLARE WORKER URL
# ----------------------------------------------------------------------------
# This is where your AI agent requests are sent
# Format: https://your-worker-name.your-account.workers.dev
# 
# Example:
VITE_AGENT_WORKER=https://affiliate-agents.myusername.workers.dev

# ----------------------------------------------------------------------------
# 2️⃣ GOOGLE OAUTH CLIENT ID  
# ----------------------------------------------------------------------------
# For Google Sign-In authentication
# Format: 123456789012-abcdefghijklmnopqrstuvwxyz.apps.googleusercontent.com
#
# Example:
VITE_GOOGLE_CLIENT_ID=123456789012-abc123xyz456.apps.googleusercontent.com

# ----------------------------------------------------------------------------
# 3️⃣ OPTIONAL: GOOGLE ANALYTICS (Optional)
# ----------------------------------------------------------------------------
# VITE_GA_ID=G-XXXXXXXXXX
```

---

## ✅ Verification Checklist

```
□ .env file exists in project root
□ .env contains VITE_AGENT_WORKER=https://...
□ .env contains VITE_GOOGLE_CLIENT_ID=...
□ No quotes around the values
□ No extra spaces
□ Development server restarted
□ Google Sign-In button appears
□ No console errors
```

---

## 🎯 Quick Reference Card

```
╔═══════════════════════════════════════════════════════════════╗
║                    CONFIGURATION REFERENCE                     ║
╠═══════════════════════════════════════════════════════════════╣
║                                                               ║
║  File to Edit:        .env (project root)                    ║
║                                                               ║
║  Variable 1:          VITE_AGENT_WORKER                      ║
║  What it is:          Your Cloudflare Worker URL             ║
║  Format:              https://name.account.workers.dev       ║
║  Get from:            WORKER_SETUP.md                        ║
║                                                               ║
║  Variable 2:          VITE_GOOGLE_CLIENT_ID                  ║
║  What it is:          Google OAuth Client ID                 ║
║  Format:              xxxxx-xxxxx.apps.googleusercontent.com ║
║  Get from:            Google Cloud Console                   ║
║                                                               ║
║  After editing:       npm run dev (restart server)           ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
```

---

## 🚦 Status Indicators

### ✅ Everything Configured Correctly
```
Browser Console:
  ✓ import.meta.env.VITE_AGENT_WORKER = "https://..."
  ✓ import.meta.env.VITE_GOOGLE_CLIENT_ID = "123456..."

Application:
  ✓ Google Sign-In button visible
  ✓ No "Worker endpoint not configured" errors
  ✓ Agents can generate responses
```

### ❌ Missing Configuration
```
Browser Console:
  ✗ import.meta.env.VITE_AGENT_WORKER = undefined
  ✗ import.meta.env.VITE_GOOGLE_CLIENT_ID = undefined

Application:
  ✗ "Worker endpoint not configured" error
  ✗ Google Sign-In not working
  ✗ Agents fail to respond
```

---

## 🛠️ Troubleshooting Decision Tree

```
                    Problem?
                       │
        ┌──────────────┼──────────────┐
        │              │              │
        ▼              ▼              ▼
   Sign-In        Worker         Both
   Not Working    Errors       Not Working
        │              │              │
        ▼              ▼              ▼
   Check          Check         Check if
   GOOGLE_        AGENT_        .env file
   CLIENT_ID      WORKER        exists
   in .env        in .env       at all
        │              │              │
        ▼              ▼              ▼
   Verify         Test          Create .env
   OAuth          Worker        and add
   setup in       is           both values
   Google         deployed
   Console
        │              │              │
        └──────────────┼──────────────┘
                       ▼
              Restart dev server
                       │
                       ▼
                  Still broken?
                       │
                       ▼
             See TROUBLESHOOTING.md
```

---

## 📚 Documentation Map

```
                    START_HERE.md
                         │
                         │
        ┌────────────────┼────────────────┐
        │                │                │
        ▼                ▼                ▼
   CHEAT_SHEET     WHERE_TO_ADD    ENVIRONMENT_
      .md          CREDENTIALS         SETUP.md
   (30 sec)           .md             (10 min)
                    (2 min)              │
                                         │
                      ┌──────────────────┘
                      │
                      ▼
            CONFIGURATION_GUIDE.md
                 (Complete)
                      │
        ┌─────────────┼─────────────┐
        │             │             │
        ▼             ▼             ▼
   WORKER_      QUICK_START_   GEMINI_
   SETUP.md     CHECKLIST.md   MIGRATION.md
        │             │             │
        └─────────────┼─────────────┘
                      │
                      ▼
              TROUBLESHOOTING.md
```

---

## 🎓 Learning Path

```
┌─────────────────────────────────────────────────────────────┐
│ BEGINNER                                                    │
│                                                             │
│ 1. WHERE_TO_ADD_CREDENTIALS.md     (2 min)  ▶ Quick answer│
│ 2. ENVIRONMENT_SETUP.md            (10 min) ▶ Visual guide │
│ 3. Edit .env file                           ▶ Add values   │
│ 4. npm run dev                              ▶ Test it      │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ INTERMEDIATE                                                │
│                                                             │
│ 1. WORKER_SETUP.md                         ▶ Deploy worker │
│ 2. Add Worker URL to .env                  ▶ Configure     │
│ 3. CONFIGURATION_GUIDE.md                  ▶ Learn more    │
│ 4. QUICK_START_CHECKLIST.md                ▶ Verify setup  │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ ADVANCED                                                    │
│                                                             │
│ 1. GEMINI_MIGRATION.md                     ▶ Optimization  │
│ 2. worker-example.js                       ▶ Worker code   │
│ 3. Production deployment                   ▶ Go live!      │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎯 One-Page Summary

```
╔════════════════════════════════════════════════════════════════╗
║         AFFILIATE AD LAUNCH STUDIO - QUICK SETUP               ║
╠════════════════════════════════════════════════════════════════╣
║                                                                ║
║  📍 File Location:                                            ║
║     .env (in your project root folder)                        ║
║                                                                ║
║  ✏️  What to Add:                                             ║
║     VITE_AGENT_WORKER=https://your-worker.workers.dev         ║
║     VITE_GOOGLE_CLIENT_ID=your-id.apps.googleusercontent.com  ║
║                                                                ║
║  🔑 Where to Get Values:                                      ║
║     Worker URL → Deploy Cloudflare Worker                     ║
║     Client ID  → Google Cloud Console                         ║
║                                                                ║
║  🚀 After Setup:                                              ║
║     npm run dev (restart development server)                  ║
║                                                                ║
║  ✅ Success Indicators:                                       ║
║     • Google Sign-In button appears                           ║
║     • No "Worker endpoint not configured" errors              ║
║     • Agents generate responses                               ║
║                                                                ║
║  📚 Need Help?                                                ║
║     • Quick:    CHEAT_SHEET.md                               ║
║     • Visual:   ENVIRONMENT_SETUP.md                         ║
║     • Complete: CONFIGURATION_GUIDE.md                       ║
║     • Issues:   TROUBLESHOOTING.md                           ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝
```

---

**Ready to start?** → [START_HERE.md](START_HERE.md) 🚀
